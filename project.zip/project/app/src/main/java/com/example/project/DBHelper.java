package com.example.project;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static DBHelper dbHelper;
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "password_managerDB";
    public static final String TABLE_PASSWORD = "password_manger";
    public static final String KEY_ID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_LOGIN = "login";
    public static final String KEY_PASSWORD = "password";
    private SQLiteDatabase DB;
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table " + TABLE_PASSWORD + "(" + KEY_ID
                + " integer primary key," + KEY_NAME + " text," + KEY_LOGIN + " text," + KEY_PASSWORD + " text" + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("drop table if exists " + TABLE_PASSWORD);

        onCreate(sqLiteDatabase);

    }
    public static DBHelper newInstance(Context context) {
        if (dbHelper == null) {
            dbHelper = new DBHelper(context);
        }
        return dbHelper;
    }
    public boolean isRegister() {
        try (SQLiteDatabase db = dbHelper.getReadableDatabase()) {
            return (DatabaseUtils.queryNumEntries(db, "password_manger") != 0);
        }
    }
}
