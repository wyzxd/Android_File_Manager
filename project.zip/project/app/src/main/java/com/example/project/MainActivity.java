package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;


public class MainActivity extends AppCompatActivity  {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DBHelper dbHelper = DBHelper.newInstance(getApplicationContext());
        boolean register = dbHelper.isRegister();
        if (register) {
            Intent intent = new Intent(this, start.class);
            startActivity(intent);
        } else {
            Intent intent1 = new Intent(this, password.class);
            startActivity(intent1);
        }
    }

}