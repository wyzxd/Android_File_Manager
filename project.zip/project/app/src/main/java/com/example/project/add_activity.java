package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

public class add_activity extends AppCompatActivity implements View.OnClickListener {
    EditText Etname, Etlogin, Etpassword;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        Button add_button = (Button) findViewById(R.id.add_button);
        add_button.setOnClickListener(this);
        Button btnRead = (Button) findViewById(R.id.btnRead);
        btnRead.setOnClickListener(this);
        Etname = (EditText) findViewById(R.id.editTextTextPersonName);
        Etlogin = (EditText) findViewById(R.id.editTextLogin);
        Etpassword = (EditText) findViewById(R.id.editTextPassword);
        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        String name = Etname.getText().toString();
        String login = Etlogin.getText().toString();
        String password = Etpassword.getText().toString();
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        switch (view.getId()){
            case R.id.add_button:
                contentValues.put(DBHelper.KEY_NAME, name);
                contentValues.put(DBHelper.KEY_LOGIN, login);
                contentValues.put(DBHelper.KEY_PASSWORD, password);
                database.insert(DBHelper.TABLE_PASSWORD, null, contentValues);
                Toast.makeText(this, "Пароль добавлен", Toast.LENGTH_LONG).show();
                break;
            case R.id.btnRead:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
        }
        dbHelper.close();
    }
}