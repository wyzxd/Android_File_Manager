package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class password extends AppCompatActivity implements View.OnClickListener {
    EditText Etpassword;
    public String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        Button add_button = (Button) findViewById(R.id.but);
        add_button.setOnClickListener(this);
        Etpassword = (EditText) findViewById(R.id.editTextText);

    }
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.but) {
            Toast.makeText(this, "Пароль добавлен", Toast.LENGTH_LONG).show();
            Etpassword = (EditText) findViewById(R.id.editTextText);
            String password = Etpassword.getText().toString();
            get_password(password, 2);
            Intent intent = new Intent(this, start.class);
            startActivity(intent);
        }
    }
    public boolean get_password(String password, int i){
        if (i == 1){
            return true;
        }
        if (i == 2){
            this.password = password;
        }
        return false;
    }
}