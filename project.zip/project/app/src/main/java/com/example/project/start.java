package com.example.project;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

public class start extends AppCompatActivity {
    DBHelper dbHelper;
    SimpleCursorAdapter scAdapter;
    ListView list;
    password pas = new password();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button_add = (Button) findViewById(R.id.addbutton);
        button_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(start.this, add_activity.class);
                startActivity(intent);
            }
        });
        dbHelper = new DBHelper(this);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        Cursor cursor = database.query("password_manger", new String[]{"_id", DBHelper.KEY_NAME},
                null, null,
                null, null, null);
        String[] from = new String[]{DBHelper.KEY_NAME};
        int[] to = new int[]{R.id.name};
        scAdapter = new SimpleCursorAdapter(start.this, R.layout.item, cursor, from, to, 0);
        list = (ListView) findViewById(R.id.listView);
        list.setAdapter(scAdapter);
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                final EditText input = new EditText(start.this);
                new AlertDialog.Builder(start.this)
                        .setTitle("Введите пароль")
                        .setMessage("для удаления")
                        .setView(input)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String value = input.getText().toString();
                                if (pas.get_password(value, 1)){
                                    delete(id);
                                }
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                            }
                        }).show();;
                return true;
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                final EditText input = new EditText(start.this);
                new AlertDialog.Builder(start.this)
                        .setTitle("Введите пароль")
                        .setMessage("для показа логина и пароля")
                        .setView(input)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String value = input.getText().toString();
                                if (pas.get_password(value, 1)){
                                    show();
                                }
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {

                            }
                        }).show();;
            }
        });
    }
    public void show(){
        dbHelper = new DBHelper(start.this);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        Cursor cursor1 = database.query("password_manger", new String[]{"_id", DBHelper.KEY_NAME, DBHelper.KEY_LOGIN, DBHelper.KEY_PASSWORD},
                null, null,
                null, null, null);
        String[] from = new String[]{DBHelper.KEY_NAME, DBHelper.KEY_LOGIN, DBHelper.KEY_PASSWORD};
        int[] to = new int[]{R.id.name, R.id.login, R.id.password};
        scAdapter = new SimpleCursorAdapter(start.this, R.layout.item, cursor1, from, to, 0);
        list = (ListView) findViewById(R.id.listView);
        list.setAdapter(scAdapter);
    }
    public void delete(long id){
        dbHelper = new DBHelper(start.this);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        database.delete(DBHelper.TABLE_PASSWORD, "_id = " + id, null);
        recreate();
    }
}